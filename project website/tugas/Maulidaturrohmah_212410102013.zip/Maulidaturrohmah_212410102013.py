Nama = "Maulidaturrohmah" # Type data String karena menunjukan huruf atau kata-kata
Nim = 212410102013 # Type data Integer karena menunjukan angka bulat atau tidak ada komanya
Umur = 18 # Type data Integer karena menunjukan angka, namun tidak ada desimalnya
TinggiBadan = 1.55 # Type data float karena menunjukan angkan, namun ada desimalnya
BeratBadan = 45 #Type data Integer karena menunjukan angka bulat atau tidak ada komanya
StatusKejombloan = "Jomblo" # String karena menunjukan huruf atau kata-kata

print (Nama) # Untuk menampilkan variabel Nama
print (Nim) # Untuk menampilkan variabel Nim
print (Umur, "Tahun") # Untuk menampilkan variabel Umur, imbuhan Tahun untuk memberikan informasi dalam satuan tahun
print (TinggiBadan, "M") # Untuk menampilkan variabel TinggiBadan, imbuhan M untuk memeberikan informai dalam satuan meter
print (BeratBadan, "kg") # Untuk menampilkan variabel BeratBadan, imbuhan kg untuk memberikan informasi dalam satuan kilogram
print (StatusKejombloan) # Untuk menampilkan variabel StatusKejombloan