Nama = "Ahmad Bagus Prayoga" # type data string karena menunjukan huruf yaitu nama 
Nim = 212410102031 # type data integer karena menunjukan angka yaitu angka dari nim 
Umur = 18 # type data Integer karena menunjukkan angka dari umur maka menggunakan tipe data integer
Tinggi_Badan = 1.80 # type data float karena satuan tinggi badan diinput kedalam satuan meter jadi satuan tersebut bakal memiliki angka desimal 
Berat_Badan = 80 # type data integer karena cuma menunjukkan angka 
Status_Kejombloan = "jomblo" # type data string karena menunjukkan kata kata atau huruf

print (Nama) # untuk menampilkan Variabel Nama
print (Nim) # untuk menampilkan Variabel Nim
print (Umur, "Tahun") 
print (Tinggi_Badan, "M") # untuk menampilkan Variabel Tinggi_Badan (imbuhan M untuk memberikan satuan terhadap tinggi badan)
print (Berat_Badan, "Kg") # untuk menampilkan Variabel Berat Badan (imbuhan kg untuk memberikan satuan terhadap berat badan)
print (Status_Kejombloan) # Untuk Menampilkan Variabel Status kejombloan